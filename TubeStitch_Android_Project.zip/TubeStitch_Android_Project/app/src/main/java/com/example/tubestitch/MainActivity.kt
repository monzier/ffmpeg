package com.example.tubestitch

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

// Holds one validated line from timeline.txt
data class SlideEntry(val imageFile: File, val durationSeconds: Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    TubeStitchApp()
                }
            }
        }
    }
}

@Composable
fun TubeStitchApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val workDir = remember { File(context.filesDir, "workspace").apply { mkdirs() } }

    // App State
    var loadedImages by remember { mutableStateOf<List<String>>(emptyList()) }
    var voiceoverName by remember { mutableStateOf<String?>(null) }
    var timelineText by remember {
        mutableStateOf(
            "# Format: image_name, duration_in_seconds\n" +
            "slide1.png, 3.0\n" +
            "slide2.png, 4.0\n" +
            "slide3.png, 3.0"
        )
    }
    var isShortsMode by remember { mutableStateOf(false) } // false = 16:9 YouTube, true = 9:16 Shorts
    var useZoomEffect by remember { mutableStateOf(false) } // subtle zoom / crossfade vs fast cut
    var isRendering by remember { mutableStateOf(false) }
    var statusLog by remember {
        mutableStateOf("Ready. Pick your images, voiceover, and timeline.txt (or tap 'Load Demo Files' to test immediately).")
    }

    // 1. Multi-Image Picker Launcher
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            scope.launch {
                val copiedNames = copyUrisToWorkDir(context, uris, workDir)
                loadedImages = (loadedImages + copiedNames).distinct()
                // Auto-fill timeline box if user hasn't customized it yet
                if (copiedNames.isNotEmpty()) {
                    timelineText = "# Format: image_name, duration_in_seconds\n" +
                        loadedImages.joinToString("\n") { "$it, 3.5" }
                }
                statusLog = "Loaded ${copiedNames.size} image(s): ${copiedNames.joinToString(", ")}"
            }
        }
    }

    // 2. Voiceover Audio Picker Launcher
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val fileName = getFileNameFromUri(context, uri) ?: "voiceover.mp3"
                val destFile = File(workDir, "voiceover_input_${fileName}")
                copyUriToFile(context, uri, destFile)
                // Always keep a standard pointer file for FFmpeg
                val standardVoiceover = File(workDir, "active_voiceover.mp3")
                destFile.copyTo(standardVoiceover, overwrite = true)
                voiceoverName = fileName
                statusLog = "Loaded voiceover audio: $fileName"
            }
        }
    }

    // 3. Timeline .txt Picker Launcher
    val txtPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val tempTxt = File(workDir, "imported_timeline.txt")
                copyUriToFile(context, uri, tempTxt)
                timelineText = tempTxt.readText()
                statusLog = "Imported timeline text file (${tempTxt.readLines().size} lines)."
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "TubeStitch Studio",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Images + Voiceover + Duration Text → MP4",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            OutlinedButton(
                onClick = {
                    scope.launch {
                        statusLog = "Generating sample slides & demo voiceover..."
                        val demoNames = createSampleAssets(workDir)
                        loadedImages = demoNames
                        voiceoverName = "demo_voiceover.mp3 (10s)"
                        timelineText =
                            "# Format: image_name, duration_in_seconds\n" +
                            "slide1.png, 3.0\n" +
                            "slide2.png, 4.0\n" +
                            "slide3.png, 3.0"
                        statusLog = "Demo files ready! Tap 'Render Video to Gallery' below."
                    }
                },
                enabled = !isRendering
            ) {
                Text("Load Demo Files", fontSize = 12.sp)
            }
        }

        // STEP 1 CARD: Pick Images & Voiceover
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("1. Select Media Files", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { imagePickerLauncher.launch(arrayOf("image/*")) },
                        enabled = !isRendering,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Pick Images (${loadedImages.size})", fontSize = 12.sp)
                    }

                    Button(
                        onClick = { audioPickerLauncher.launch(arrayOf("audio/*")) },
                        enabled = !isRendering,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = if (voiceoverName == null) "Pick Voiceover" else "Audio Loaded ✓",
                            fontSize = 12.sp
                        )
                    }
                }

                if (loadedImages.isNotEmpty()) {
                    Text(
                        text = "Loaded images: ${loadedImages.joinToString(", ")}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (voiceoverName != null) {
                    Text(
                        text = "Voiceover: $voiceoverName",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // STEP 2 CARD: Timeline.txt Editor & Import
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("2. Timeline Durations (timeline.txt)", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    TextButton(
                        onClick = { txtPickerLauncher.launch(arrayOf("text/plain")) },
                        enabled = !isRendering
                    ) {
                        Text("Import .txt", fontSize = 12.sp)
                    }
                }

                OutlinedTextField(
                    value = timelineText,
                    onValueChange = { timelineText = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(145.dp),
                    textStyle = LocalTextStyle.current.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp
                    ),
                    placeholder = { Text("slide1.png, 3.0\nslide2.png, 4.0") }
                )
            }
        }

        // STEP 3 CARD: Video Format Settings (16:9 vs 9:16 Shorts)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("3. YouTube Output Format", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isShortsMode) "Format: 9:16 YouTube Shorts (1080×1920)" else "Format: 16:9 YouTube HD (1920×1080)",
                        fontSize = 13.sp
                    )
                    Switch(
                        checked = isShortsMode,
                        onCheckedChange = { isShortsMode = it },
                        enabled = !isRendering
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Smooth Fade-In Transitions",
                        fontSize = 13.sp
                    )
                    Switch(
                        checked = useZoomEffect,
                        onCheckedChange = { useZoomEffect = it },
                        enabled = !isRendering
                    )
                }
            }
        }

        // RENDER BUTTON
        Button(
            onClick = {
                isRendering = true
                statusLog = "Starting render pipeline..."
                scope.launch {
                    val finalReport = renderCompleteVideo(
                        context = context,
                        workDir = workDir,
                        timelineContent = timelineText,
                        isShorts = isShortsMode,
                        addFade = useZoomEffect
                    ) { progressMsg ->
                        statusLog = progressMsg
                    }
                    statusLog = finalReport
                    isRendering = false
                }
            },
            enabled = !isRendering,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = if (isRendering) "Rendering MP4 with FFmpeg..." else "Render Video to Phone Gallery",
                modifier = Modifier.padding(vertical = 8.dp),
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // STATUS & FFMPEG LOG BOX
        Text("Status & FFmpeg Log:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp)
                )
                .padding(12.dp)
        ) {
            Text(
                text = statusLog,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * Full pipeline: validates files (or creates demo files if none picked yet),
 * runs FFmpeg concat + voiceover merge, and exports the MP4 to the phone's Movies/TubeStitch gallery.
 */
suspend fun renderCompleteVideo(
    context: Context,
    workDir: File,
    timelineContent: String,
    isShorts: Boolean,
    addFade: Boolean,
    onProgress: (String) -> Unit
): String = withContext(Dispatchers.IO) {

    // If user hasn't picked a voiceover yet, auto-create demo assets so first run never fails
    val voiceoverFile = File(workDir, "active_voiceover.mp3")
    if (!voiceoverFile.exists()) {
        onProgress("No custom files picked yet — generating starter demo slides & voiceover...")
        createSampleAssets(workDir)
    }

    val timelineFile = File(workDir, "timeline.txt")
    timelineFile.writeText(timelineContent)

    onProgress("1/4 Parsing timeline.txt...")
    val slides = try {
        parseTimelineFile(timelineFile, workDir)
    } catch (e: Exception) {
        return@withContext "Timeline Error:\n${e.message}"
    }

    onProgress("2/4 Writing FFmpeg concat sequence (${slides.size} slides)...")
    val concatFile = File(workDir, "_ffmpeg_concat.txt")
    writeFfmpegConcatFile(slides, concatFile)

    val outputVideo = File(workDir, "tubestitch_output.mp4")
    if (outputVideo.exists()) outputVideo.delete()

    val targetW = if (isShorts) 1080 else 1920
    val targetH = if (isShorts) 1920 else 1080

    val fadeFilter = if (addFade) ",fade=t=in:st=0:d=0.4" else ""
    val videoFilter =
        "scale=$targetW:$targetH:force_original_aspect_ratio=decrease," +
        "pad=$targetW:$targetH:(ow-iw)/2:(oh-ih)/2," +
        "format=yuv420p$fadeFilter"

    val command = listOf(
        "-y",
        "-f", "concat",
        "-safe", "0",
        "-i", "\"${concatFile.absolutePath}\"",
        "-i", "\"${voiceoverFile.absolutePath}\"",
        "-vf", "\"$videoFilter\"",
        "-r", "30",
        "-c:v", "libx264",
        "-preset", "ultrafast",
        "-c:a", "aac",
        "-b:a", "192k",
        "-shortest",
        "\"${outputVideo.absolutePath}\""
    ).joinToString(" ")

    onProgress("3/4 Encoding ${targetW}x${targetH} MP4 with FFmpeg...")
    val session = FFmpegKit.execute(command)

    if (!ReturnCode.isSuccess(session.returnCode)) {
        return@withContext "FFmpeg Render Error:\n${session.allLogsAsString}"
    }

    onProgress("4/4 Saving MP4 to your phone's Movies/TubeStitch gallery folder...")
    val savedLocation = saveVideoToGallery(context, outputVideo)

    val sizeKb = outputVideo.length() / 1024
    "SUCCESS! Your YouTube video is ready!\n\n" +
    "Gallery Location: $savedLocation\n" +
    "Resolution: ${targetW}x${targetH} (30 FPS)\n" +
    "Slides Stitched: ${slides.size}\n" +
    "File Size: ${sizeKb} KB"
}

/**
 * Copies user-selected image URIs into the app's workspace folder preserving their original filenames.
 */
suspend fun copyUrisToWorkDir(context: Context, uris: List<Uri>, workDir: File): List<String> =
    withContext(Dispatchers.IO) {
        val names = mutableListOf<String>()
        for (uri in uris) {
            val name = getFileNameFromUri(context, uri) ?: "image_${System.currentTimeMillis()}.png"
            val dest = File(workDir, name)
            copyUriToFile(context, uri, dest)
            names.add(name)
        }
        names
    }

suspend fun copyUriToFile(context: Context, uri: Uri, destFile: File) = withContext(Dispatchers.IO) {
    context.contentResolver.openInputStream(uri)?.use { input ->
        FileOutputStream(destFile).use { output ->
            input.copyTo(output)
        }
    }
}

fun getFileNameFromUri(context: Context, uri: Uri): String? {
    var result: String? = null
    if (uri.scheme == "content") {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) result = cursor.getString(idx)
            }
        }
    }
    if (result == null) {
        result = uri.path?.substringAfterLast('/')
    }
    return result
}

/**
 * Saves the rendered MP4 into the phone's public Movies/TubeStitch folder so it appears in Gallery & YouTube.
 */
fun saveVideoToGallery(context: Context, videoFile: File): String {
    val fileName = "TubeStitch_${System.currentTimeMillis()}.mp4"
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/TubeStitch")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val itemUri = resolver.insert(collection, values)
            if (itemUri != null) {
                resolver.openOutputStream(itemUri)?.use { outStream ->
                    FileInputStream(videoFile).use { inStream ->
                        inStream.copyTo(outStream)
                    }
                }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
                "Movies/TubeStitch/$fileName"
            } else {
                videoFile.absolutePath
            }
        } else {
            val moviesDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "TubeStitch"
            ).apply { mkdirs() }
            val destFile = File(moviesDir, fileName)
            videoFile.copyTo(destFile, overwrite = true)
            destFile.absolutePath
        }
    } catch (e: Exception) {
        videoFile.absolutePath
    }
}

/**
 * Creates 3 starter 1280x720 PNG images and a 10-second voiceover track for one-tap testing.
 */
fun createSampleAssets(workDir: File): List<String> {
    val sampleSlides = listOf(
        Triple("slide1.png", Color.parseColor("#1E293B"), "Slide 1: Hook & Intro (3s)"),
        Triple("slide2.png", Color.parseColor("#0F766E"), "Slide 2: Main Story Beat (4s)"),
        Triple("slide3.png", Color.parseColor("#4338CA"), "Slide 3: Outro & Subscribe (3s)")
    )

    val createdNames = mutableListOf<String>()
    for ((filename, bgColor, label) in sampleSlides) {
        val file = File(workDir, filename)
        val bitmap = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(bgColor)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 54f
        }
        canvas.drawText(label, 90f, 360f, paint)

        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        createdNames.add(filename)
    }

    val voiceoverFile = File(workDir, "active_voiceover.mp3")
    FFmpegKit.execute(
        "-y -f lavfi -i sine=frequency=440:duration=10 -af volume=0.15 \"${voiceoverFile.absolutePath}\""
    )
    return createdNames
}

/**
 * Parses timeline.txt where each line is: image_filename.png, duration_in_seconds
 */
fun parseTimelineFile(timelineFile: File, imageFolder: File): List<SlideEntry> {
    val slides = mutableListOf<SlideEntry>()

    timelineFile.readLines().forEachIndexed { index, rawLine ->
        val lineNum = index + 1
        val line = rawLine.trim()
        if (line.isEmpty() || line.startsWith("#")) return@forEachIndexed

        val parts = line.split(",").map { it.trim() }
        require(parts.size == 2) {
            "Line $lineNum must be 'image_name.png, seconds' -> found: $line"
        }

        val imageFile = File(imageFolder, parts[0])
        require(imageFile.exists()) {
            "Line $lineNum: Image '${parts[0]}' was not found. Make sure you picked '${parts[0]}' using Pick Images."
        }

        val duration = parts[1].toDoubleOrNull()
        require(duration != null && duration > 0) {
            "Line $lineNum: Duration '${parts[1]}' must be a positive number."
        }

        slides.add(SlideEntry(imageFile, duration))
    }

    require(slides.isNotEmpty()) { "timeline.txt has no valid slide lines." }
    return slides
}

/**
 * Writes _ffmpeg_concat.txt and repeats the final image entry so FFmpeg respects its duration.
 */
fun writeFfmpegConcatFile(slides: List<SlideEntry>, concatFile: File) {
    val builder = StringBuilder()
    for (slide in slides) {
        val safePath = slide.imageFile.absolutePath.replace("'", "'\\''")
        builder.appendLine("file '$safePath'")
        builder.appendLine("duration ${slide.durationSeconds}")
    }
    val lastSafePath = slides.last().imageFile.absolutePath.replace("'", "'\\''")
    builder.appendLine("file '$lastSafePath'")

    concatFile.writeText(builder.toString())
}